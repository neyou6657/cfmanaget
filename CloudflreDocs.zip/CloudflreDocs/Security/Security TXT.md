Security TXT
SecurityTXT
Methods
client.SecurityTXT.Get(ctx, query) (*
SecurityTXTGetResponse
, error)
get/zones/{zone_id}/security-center/securitytxt
Get security.txt
client.SecurityTXT.Update(ctx, params) (*
SecurityTXTUpdateResponse
, error)
put/zones/{zone_id}/security-center/securitytxt
Update security.txt
client.SecurityTXT.Delete(ctx, body) (*
SecurityTXTDeleteResponse
, error)
delete/zones/{zone_id}/security-center/securitytxt
Delete security.txt