IPs
IPs
Methods
client.IPs.List(ctx, query) (*
IPListResponse
, error)
get/ips
Get IPs used on the Cloudflare/JD Cloud network, see https://www.cloudflare.com/ips for Cloudflare IPs or https://developers.cloudflare.com/china-network/reference/infrastructure/ for JD Cloud IPs.
Domain types
typeIPs[]
IPsItem
The set of IPs on the Address Map.