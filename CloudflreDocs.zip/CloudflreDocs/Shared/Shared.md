Shared
Shared
Domain types
typeASNint64
typeAuditLogstruct{…}
typeCertificateCAstring
The Certificate Authority that will issue the certificate
typeCertificateRequestTypestring
Signature type desired on certificate ("origin-rsa" (rsa), "origin-ecc" (ecdsa), or "keyless-certificate" (for Keyless SSL servers).
typeCloudflareTunnelstruct{…}
A Cloudflare Tunnel that connects your origin to Cloudflare's edge.
typeErrorDatastruct{…}
typeIdentifierstruct{…}
typeLoadBalancerPreviewstruct{…}
typeMemberstruct{…}
typePaginationInfostruct{…}
typePermissionstring
typePermissionGrantstruct{…}
typeRatePlanstruct{…}
The rate plan applied to the subscription.
typeResponseInfostruct{…}
typeResultinterface{…}
typeRolestruct{…}
typeSortDirectionstring
Direction to order DNS records in.
typeSubscriptionstruct{…}
typeSubscriptionComponentstruct{…}
A component value for a subscription.
typeSubscriptionZonestruct{…}
A simple zone object. May have null properties if not a zone subscription.
typeTokenstruct{…}
typeTokenConditionCIDRListstring
IPv4/IPv6 CIDR.
typeTokenPolicystruct{…}
typeTokenValuestring
The token value.