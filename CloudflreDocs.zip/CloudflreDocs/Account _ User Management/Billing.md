Billing
Billing
Billing
Profiles
Billing.Profiles
Methods
client.Billing.Profiles.Get(ctx, query) (*
ProfileGetResponse
, error)
Deprecated
get/accounts/{account_id}/billing/profile
Gets the current billing profile for the account.