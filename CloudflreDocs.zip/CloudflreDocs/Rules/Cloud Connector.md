Cloud Connector
CloudConnector
Cloud Connector
Rules
CloudConnector.Rules
Methods
client.CloudConnector.Rules.List(ctx, query) (*SinglePage[
RuleListResponse
], error)
get/zones/{zone_id}/cloud_connector/rules
Rules
client.CloudConnector.Rules.Update(ctx, params) (*SinglePage[
RuleUpdateResponse
], error)
put/zones/{zone_id}/cloud_connector/rules
Put Rules