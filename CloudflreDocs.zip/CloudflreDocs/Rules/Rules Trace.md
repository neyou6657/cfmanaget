Rules Trace
RequestTracers
Rules Trace
Traces
RequestTracers.Traces
Methods
client.RequestTracers.Traces.New(ctx, params) (*
TraceNewResponse
, error)
post/accounts/{account_id}/request-tracer/trace
Request Trace
Domain types
typeTrace[]
TraceItem
typeTraceItemstruct{…}
List of steps acting on request/response