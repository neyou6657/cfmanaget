Certificate Authorities
CertificateAuthorities
Certificate Authorities
Hostname Associations
CertificateAuthorities.HostnameAssociations
Methods
client.CertificateAuthorities.HostnameAssociations.Get(ctx, params) (*
HostnameAssociationGetResponse
, error)
get/zones/{zone_id}/certificate_authorities/hostname_associations
List Hostname Associations
client.CertificateAuthorities.HostnameAssociations.Update(ctx, params) (*
HostnameAssociationUpdateResponse
, error)
put/zones/{zone_id}/certificate_authorities/hostname_associations
Replace Hostname Associations
Domain types
typeHostnameAssociationstring
typeTLSHostnameAssociationstruct{…}