DCV Delegation
DCVDelegation
Methods
client.DCVDelegation.Get(ctx, query) (*
DCVDelegationUUID
, error)
get/zones/{zone_id}/dcv_delegation/uuid
Retrieve the account and zone specific unique identifier used as part of the CNAME target for DCV Delegation.
Domain types
typeDCVDelegationUUIDstruct{…}